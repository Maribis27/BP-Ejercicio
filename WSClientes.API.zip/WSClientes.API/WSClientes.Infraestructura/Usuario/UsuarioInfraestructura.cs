﻿using WSClientes.Dominio.Usuario;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades.Datos.Salida;
using WSClientes.Entidades.Datos;

namespace WSClientes.Infraestructura.Usuario
{
    public class UsuarioInfraestructura : IUsuarioInfraestructura

    {
        private readonly IUsuarioRepositorio _usuarioRepositorio;

        public UsuarioInfraestructura(IUsuarioRepositorio usuarioRepositorio)
        {
            _usuarioRepositorio = usuarioRepositorio;
        }

        public async Task<SalidaConsultaUsuario> Consulta(EntradaConsultaUsuario entradaConsultaUsuario)
        {
            SalidaConsultaUsuario salidaConsultaUsuario = new SalidaConsultaUsuario();
            List<UsuarioConsulta> resultadoConsulta = new List<UsuarioConsulta>();
            resultadoConsulta = await _usuarioRepositorio.Consulta(entradaConsultaUsuario);
            salidaConsultaUsuario.Usuario = resultadoConsulta;
            return salidaConsultaUsuario;

        }

        public async Task<SalidaCreaUsuario> CreaAsync(EntradaCreaUsuario entradaCreaUsuario)
        {
            var resultadoCrea = await _usuarioRepositorio.CreaAsync(entradaCreaUsuario);

            SalidaCreaUsuario salidaCreaUsuario= new SalidaCreaUsuario();
            salidaCreaUsuario.UsuarioId = resultadoCrea;

            return salidaCreaUsuario;
        }


        public async Task<bool> ActualizaAsync(EntradaActualizaUsuario entradaActualizaUsuario)
        {
            if (!await _usuarioRepositorio.ActualizaAsync(entradaActualizaUsuario.Usuario))
                return false;

            return true;
        }

        public async Task<bool> EliminaAsync(EntradaEliminaUsuario entradaEliminaUsuario)
        {

            if (!(await _usuarioRepositorio.EliminaAsync(entradaEliminaUsuario.Usuario)))
                return false;

            return true;
        }
    }
}
