﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSClientes.Dominio.Cliente;
using WSClientes.Entidades.Datos;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades.Datos.Salida;

namespace WSClientes.Infraestructura.Cliente
{
    public class ClienteInfraestructura : IClienteInfraestructura
    {
        private readonly IClienteRepositorio _clienteRepositorio;

        public ClienteInfraestructura(IClienteRepositorio clienteRepositorio)
        {
            _clienteRepositorio = clienteRepositorio;
        }

        public async Task<SalidaConsultaClientes> Consulta(EntradaConsultaCliente entradaConsultaCliente)
        {
            SalidaConsultaClientes salidaConsultaUsuario = new SalidaConsultaClientes();
            List<ClienteConsulta> resultadoConsulta = new List<ClienteConsulta>();
            resultadoConsulta = await _clienteRepositorio.Consulta(entradaConsultaCliente);
            salidaConsultaUsuario.Clientes = resultadoConsulta;
            return salidaConsultaUsuario;
        }

    }
}
