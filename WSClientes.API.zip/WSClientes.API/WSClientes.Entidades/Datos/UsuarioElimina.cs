﻿namespace WSClientes.Entidades.Datos
{
    public class UsuarioElimina
    {
        public long Id { get; set; } = 0;
        public string Identificacion { get; set; } = string.Empty;
    }
}
