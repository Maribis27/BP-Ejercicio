﻿namespace WSClientes.Entidades.Datos
{
    public class ClienteConsulta
    {
        public long Id { get; set; } = 0;
        public long IdUsuario { get; set; } = 0;
        public UsuarioConsulta Usuario { get; set; } = null!;
        public string Contrasenia { get; set; } = string.Empty;
        public bool Estado { get; set; } = true;

    }
}