﻿namespace WSClientes.Entidades.Datos
{
    public class ClienteId
    {
        public long? Id { get; set; } = null;

    }
}