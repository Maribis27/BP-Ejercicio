﻿namespace WSClientes.Entidades.Datos
{
    public class UsuarioId
    {
        public long Id { get; set; } = 0;
    }
}
