﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaActualizaCliente
    {
        public ClienteActualiza Cliente { get; set; } = new ClienteActualiza();
    }
}