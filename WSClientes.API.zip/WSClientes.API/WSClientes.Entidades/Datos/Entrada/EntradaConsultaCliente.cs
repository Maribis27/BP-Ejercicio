﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaConsultaCliente
    {
        public long? IdCliente { get; set; } = null;
        public long? IdUsuario { get; set; } = null;

    }
}