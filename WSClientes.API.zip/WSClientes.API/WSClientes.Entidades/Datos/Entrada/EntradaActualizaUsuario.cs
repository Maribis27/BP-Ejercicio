﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaActualizaUsuario
    {
        public UsuarioActualiza Usuario { get; set; } = new UsuarioActualiza();
    }
}
