﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaCreaCliente
    {
        public ClienteCrea Cliente { get; set; } = new ClienteCrea();

    }
}