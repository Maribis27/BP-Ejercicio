﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaEliminaUsuario
    {
        public UsuarioElimina Usuario { get; set; } = new UsuarioElimina();
    }
}
