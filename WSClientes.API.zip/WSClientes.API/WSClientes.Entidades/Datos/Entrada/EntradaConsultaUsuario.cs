﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaConsultaUsuario
    {
        public string Identificacion { get; set; } = "";
    }
}
