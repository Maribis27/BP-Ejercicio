﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaCreaUsuario
    {
        public UsuarioCrea Usuario { get; set; } = new UsuarioCrea();
    }
}
