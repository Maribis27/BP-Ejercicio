﻿namespace WSClientes.Entidades.Datos.Entrada
{
    public class EntradaEliminaCliente
    {
        public ClienteElimina Cliente { get; set; } = new ClienteElimina();
    }
}