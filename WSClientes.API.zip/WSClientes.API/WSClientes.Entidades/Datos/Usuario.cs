﻿namespace WSClientes.Entidades.Datos
{
    public class Usuario
    {
        public string Identificacion { get; set; } = string.Empty;
    }
}
