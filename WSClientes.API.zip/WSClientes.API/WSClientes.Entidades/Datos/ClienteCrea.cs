﻿
namespace WSClientes.Entidades.Datos
{
    public class ClienteCrea
    {
        public long IdPersona { get; set; } = 0;
        public string Contrasenia { get; set; } = string.Empty;

    }
}