﻿namespace WSClientes.Entidades.Datos
{
    public class ClienteElimina
    {
        public long Id { get; set; } = 0;

    }
}