﻿namespace WSClientes.Entidades.Datos.Salida
{
    public class SalidaConsultaCuenta
    {
       // public List<CuentaConsulta> Cuentas { get; set; } = new List<CuentaConsulta>();

    }
}