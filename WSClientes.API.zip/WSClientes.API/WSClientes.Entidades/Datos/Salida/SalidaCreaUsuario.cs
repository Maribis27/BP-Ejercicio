﻿namespace WSClientes.Entidades.Datos.Salida
{
    public class SalidaCreaUsuario
    {
        public UsuarioId UsuarioId { get; set; } = new UsuarioId();
    }
}
