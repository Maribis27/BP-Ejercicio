﻿namespace WSClientes.Entidades.Datos.Salida
{
    public class SalidaConsultaClientes
    {
        public List<ClienteConsulta> Clientes { get; set; } = new List<ClienteConsulta>();
    }
}
