﻿
namespace WSClientes.Entidades.Datos.Salida
{
    public class SalidaCreaCliente
    {
        /// <summary>
        /// 
        /// </summary>
        public ClienteId Cliente { get; set; } = new ClienteId();
    }
}