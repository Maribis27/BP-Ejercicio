﻿namespace WSClientes.Entidades.Datos.Salida
{
    public class SalidaConsultaUsuario
    {
        public List<UsuarioConsulta> Usuario { get; set; } = new List<UsuarioConsulta>();
    }
}
