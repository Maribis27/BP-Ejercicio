﻿namespace WSClientes.Entidades
{
    public class EConstantes
    {
        public const string ConexionBdd = "Server=DESKTOP-78B9VQO\\SQL2022;Database=BDD_CLIENTES;Trusted_Connection=True;TrustServerCertificate=True;";

        public const string Consulta = "Consulta";

        public const string Crea = "Crea";

        public const string Actualiza = "Actualiza";

        public const string Elimina = "Elimina";


        public const string EnpointCabecera = "EnpointCabecera";

        
    }
}
