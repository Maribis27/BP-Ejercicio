﻿namespace WSClientes.Entidades.ModeloBD
{
    public partial class BCUsuario
    {
        public BCUsuario()
        {
            BCCliente = new HashSet<BCCliente>();
            BCCuenta = new HashSet<BCCuenta>();
        }

        public long IdUsuario { get; set; }
        public string Nombre { get; set; } = null!;
        public string Genero { get; set; } = null!;
        public int Edad { get; set; }
        public string Identificacion { get; set; } = null!;
        public string? Direccion { get; set; }
        public int? Telefono { get; set; }
        public virtual ICollection<BCCliente> BCCliente { get; set; }
        public virtual ICollection<BCCuenta> BCCuenta { get; set; }
    }
}
