﻿namespace WSClientes.Entidades.ModeloBD
{
    public partial class BCCliente
    {
        public long IdCliente { get; set; }
        public long IdUsuario { get; set; }
        public string Contrasenia { get; set; } = null!;
        public bool Estado { get; set; }

        public virtual BCUsuario IdUsuarioBC{ get; set; } = null!;
    }
}
