﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSClientes.Entidades.ModeloBD
{
    public partial class BCCuenta
    {
        public BCCuenta()
        {
            BCMovimientos = new HashSet<BCMovimiento>();
        }

        public long IdCuenta { get; set; }
        public long IdPersona { get; set; }
        public int NumeroCuenta { get; set; }
        public string TipoCuenta { get; set; } = null!;
        public decimal SaldoInicial { get; set; }
        public bool? Estado { get; set; }

        public virtual BCUsuario IdUsuario { get; set; } = null!;
        public virtual ICollection<BCMovimiento> BCMovimientos { get; set; }
    }

}

