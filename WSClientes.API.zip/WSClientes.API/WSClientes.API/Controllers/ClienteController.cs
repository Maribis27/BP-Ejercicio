﻿using Microsoft.AspNetCore.Mvc;
using WSClientes.Dominio.Cliente;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades;


namespace WSClientes.API.Controllers
{
    [ApiController]
    [Route("api/v1/WSClientes/[controller]")]
    public class ClienteController : Controller
    {
        private readonly IClienteInfraestructura _ClienteInfraestructura;

        public ClienteController(IClienteInfraestructura ClienteInfraestructura)
        {
            _ClienteInfraestructura = ClienteInfraestructura;
        }

        [HttpGet]
        [Route(EConstantes.Consulta)]
        public async Task<ActionResult> Consulta(EntradaConsultaCliente eEntradaConsultaCliente)
        {
            return Ok(await _ClienteInfraestructura.Consulta(eEntradaConsultaCliente));
        }
    }
}
