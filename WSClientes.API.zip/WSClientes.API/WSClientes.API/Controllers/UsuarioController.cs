﻿using Microsoft.AspNetCore.Mvc;
using WSClientes.Dominio.Usuario;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades;
using WSClientes.Dominio.Usuario;

namespace WSClientes.API.Controllers
{
    [ApiController]
    [Route("api/v1/WSClientes/[controller]")]
    public class UsuarioController : Controller
    {
        private readonly IUsuarioInfraestructura _UsuarioInfraestructura;

        public UsuarioController(IUsuarioInfraestructura UsuarioInfraestructura)
        {
            _UsuarioInfraestructura = UsuarioInfraestructura;
        }

        [HttpGet]
        [Route(EConstantes.Consulta)]
        public async Task<ActionResult> Consulta(EntradaConsultaUsuario eEntradaConsultaUsuario)
        {
            return Ok(await _UsuarioInfraestructura.Consulta(eEntradaConsultaUsuario));
        }

        [HttpPost]
        [Route(EConstantes.Crea)]
        public async Task<ActionResult> CreaUsuarioAsync(EntradaCreaUsuario entradaCreaUsuario)
        {
            return Ok(await _UsuarioInfraestructura.CreaAsync(entradaCreaUsuario));
        }

        [HttpPut]
        [Route(EConstantes.Actualiza)]
        public async Task<ActionResult> ActualizaUsuarioAsync(EntradaActualizaUsuario entradaActualizaUsuario)
        {
            return Ok(await _UsuarioInfraestructura.ActualizaAsync(entradaActualizaUsuario));
        }

        [HttpDelete]
        [Route(EConstantes.Elimina)]
        public async Task<ActionResult> EliminaUsuario(EntradaEliminaUsuario entradaEliminaUsuario)
        {
            return Ok(await _UsuarioInfraestructura.EliminaAsync(entradaEliminaUsuario));
        }
    }
}

