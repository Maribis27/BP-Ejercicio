using WSClientes.Dominio.Cliente;
using WSClientes.Dominio.Usuario;
using WSClientes.Infraestructura.Cliente;
using WSClientes.Infraestructura.Usuario;
using WSClientes.Repositario.Cliente;
using WSClientes.Repositario.Configuraciones.Contexto;
using WSClientes.Repositario.Usuario;


var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

#region Repositorio
builder.Services.AddTransient<IUsuarioRepositorio, UsuarioRepositorio>();
builder.Services.AddTransient<IClienteRepositorio, ClienteRepositorio>();




builder.Services.AddDbContext<BddContexto>();
#endregion


builder.Services.AddTransient<IUsuarioInfraestructura, UsuarioInfraestructura>();
builder.Services.AddTransient<IClienteInfraestructura, ClienteInfraestructura>();



builder.Services.AddCors(options => options.AddPolicy("AllowAll", p => p.AllowAnyOrigin()
                                                   .AllowAnyMethod()
                                                   .AllowAnyHeader()));



builder.Services.AddApiVersioning(options => options.UseApiBehavior = true);
builder.Services.AddApiVersioning(options => options.AssumeDefaultVersionWhenUnspecified = true);



builder.Services.AddHealthChecks();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{

}
//app.UseHealthChecks("/api/v1/WSClientes/EnpointCabecera");


app.UseHttpsRedirection();
app.UseAuthorization();
app.UseCors("AllowAll");

#region SWAGGER DOCUMENT

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "WSClientes.API V1");
});
#endregion Swagger

app.MapControllers();
app.Run();