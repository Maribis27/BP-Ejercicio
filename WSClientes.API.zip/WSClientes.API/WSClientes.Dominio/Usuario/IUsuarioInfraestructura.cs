﻿
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades.Datos.Salida;

namespace WSClientes.Dominio.Usuario
{
    public interface IUsuarioInfraestructura
    {
        Task<SalidaConsultaUsuario> Consulta(EntradaConsultaUsuario entradaConsultaUsuario);
        Task<SalidaCreaUsuario> CreaAsync(EntradaCreaUsuario entradaCreaUsuario);
        Task<bool> ActualizaAsync(EntradaActualizaUsuario entradaActualizaUsuario);
        Task<bool> EliminaAsync(EntradaEliminaUsuario entradaEliminaUsuario);
    }
}
