﻿using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades.Datos;

namespace WSClientes.Dominio.Usuario
{
    public interface IUsuarioRepositorio
    {
        Task<List<UsuarioConsulta>> Consulta(EntradaConsultaUsuario entradaConsultaUsuario);
        Task<UsuarioId> CreaAsync(EntradaCreaUsuario entradaCreaUsuario);
        Task<bool> ActualizaAsync(UsuarioActualiza usuarioActualiza);
        Task<bool> EliminaAsync(UsuarioElimina usuarioElimina);
    }
}
