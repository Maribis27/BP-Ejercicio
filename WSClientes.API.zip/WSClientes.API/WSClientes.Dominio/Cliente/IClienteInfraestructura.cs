﻿
using WSClientes.Entidades.Datos.Salida;
using WSClientes.Entidades.Datos.Entrada;

namespace WSClientes.Dominio.Cliente
{
    public interface IClienteInfraestructura
    {
        Task<SalidaConsultaClientes> Consulta(EntradaConsultaCliente entradaConsutaCliente);
        //Task<SalidaCreaCliente> Crea(EntradaCreaCliente entradaCreaCliente);
        //Task<bool> Actualiza(EntradaActualizaCliente entradaActualizaCliente);
        //Task<bool> Elimina(EntradaEliminaCliente entradaEliminaCliente);
    }
}
