﻿using WSClientes.Entidades.Datos;
using WSClientes.Entidades.Datos.Entrada;

namespace WSClientes.Dominio.Cliente
{
    public interface IClienteRepositorio
    {
        Task<List<ClienteConsulta>> Consulta(EntradaConsultaCliente entradaConsultaCliente);
        //Task<ClienteId> Crea(ClienteCrea clienteCrea);
        //Task<bool> Actualiza(ClienteActualiza clienteActualiza);
        //Task<bool> Elimina(ClienteElimina clienteElimina);

    }
}
