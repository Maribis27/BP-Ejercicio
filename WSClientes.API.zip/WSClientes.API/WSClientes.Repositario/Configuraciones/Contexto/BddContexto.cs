﻿using Microsoft.EntityFrameworkCore;
using WSClientes.Entidades;
using WSClientes.Entidades.ModeloBD;
namespace WSClientes.Repositario.Configuraciones.Contexto
{
    public partial class BddContexto : DbContext
    {
        public BddContexto()
        {
        }

        public BddContexto(DbContextOptions<BddContexto> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(EConstantes.ConexionBdd);
            }
        }

        public virtual DbSet<BCUsuario> BcUsuario { get; set; } = null!;
        public virtual DbSet<BCCliente> BcCliente { get; set; } = null!;
        public virtual DbSet<BCCuenta> BcCuenta { get; set; } = null!;
        public virtual DbSet<BCMovimiento> BcMovimientos { get; set; } = null!;
 
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<BCUsuario>(entity =>
            {
                entity.HasKey(e => e.IdUsuario)
                    .HasName("PK__BC_USUAR__91136B909A1DBA78");

                entity.ToTable("BC_USUARIO");

                entity.Property(e => e.IdUsuario).HasColumnName("ID_USUARIO");

                entity.Property(e => e.Direccion)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("DIRECCION");

                entity.Property(e => e.Edad).HasColumnName("EDAD");

                entity.Property(e => e.Genero)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GENERO")
                    .IsFixedLength();

                entity.Property(e => e.Identificacion)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("IDENTIFICACION");

                entity.Property(e => e.Nombre)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("NOMBRE");

                entity.Property(e => e.Telefono).HasColumnName("TELEFONO");
            });
                     


            modelBuilder.Entity<BCCliente>(entity =>
            {
                entity.HasKey(e => e.IdCliente)
                    .HasName("PK__BC_CLIEN__23A341303964BF0F");

                entity.ToTable("BC_CLIENTE");

                entity.Property(e => e.IdCliente).HasColumnName("ID_CLIENTE");

                entity.Property(e => e.Contrasenia)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("CONTRASENIA");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("ESTADO")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.IdUsuario).HasColumnName("ID_USUARIO");

                entity.HasOne(d => d.IdUsuarioBC)
                    .WithMany(p => p.BCCliente)
                    .HasForeignKey(d => d.IdUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BC_CLIENTE_BC_USUARIO");
            });

            modelBuilder.Entity<BCCuenta>(entity =>
            {
                entity.HasKey(e => e.IdCuenta)
                    .HasName("PK__BC_CUENT__ADEAD61A565E1A48");

                entity.ToTable("BC_CUENTA");

                entity.Property(e => e.IdCuenta).HasColumnName("ID_CUENTA");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasColumnName("ESTADO")
                    .HasDefaultValueSql("('1')");

                entity.Property(e => e.IdPersona).HasColumnName("ID_PERSONA");

                entity.Property(e => e.NumeroCuenta).HasColumnName("NUMERO_CUENTA");

                entity.Property(e => e.SaldoInicial)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("SALDO_INICIAL")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.TipoCuenta)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("TIPO_CUENTA");

                entity.HasOne(d => d.IdUsuario)
                    .WithMany(p => p.BCCuenta)
                    .HasForeignKey(d => d.IdPersona)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BC_CUENTA_BC_USUARIO");
            });

            modelBuilder.Entity<BCMovimiento>(entity =>
            {
                entity.HasKey(e => e.IdMovimientos)
                    .HasName("PK__BC_MOVIM__CEB714B3637DFB39");

                entity.ToTable("BC_MOVIMIENTOS");

                entity.Property(e => e.IdMovimientos).HasColumnName("ID_MOVIMIENTOS");

                entity.Property(e => e.Fecha)
                    .HasColumnType("datetime")
                    .HasColumnName("FECHA")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdCuenta).HasColumnName("ID_CUENTA");

                entity.Property(e => e.Saldo)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("SALDO");

                entity.Property(e => e.Tipo)
                    .HasMaxLength(3)
                    .HasColumnName("TIPO");

                entity.Property(e => e.Valor)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("VALOR");

                entity.HasOne(d => d.IdCuentaNavigation)
                    .WithMany(p => p.BCMovimientos)
                    .HasForeignKey(d => d.IdCuenta)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BC_MOVIMIENTOS_BC_CUENTA");
            });

            

            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

