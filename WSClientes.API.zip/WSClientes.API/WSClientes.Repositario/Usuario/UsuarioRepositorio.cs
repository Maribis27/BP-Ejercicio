﻿using WSClientes.Dominio.Usuario;
using WSClientes.Entidades.Datos;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades.ModeloBD;
using WSClientes.Repositario.Configuraciones.Contexto;
using Microsoft.EntityFrameworkCore;

namespace WSClientes.Repositario.Usuario 
{
    public class UsuarioRepositorio: IUsuarioRepositorio
    {

        private readonly BddContexto _iBddContexto;

        public UsuarioRepositorio(BddContexto bddContexto)
        {
            _iBddContexto = bddContexto;
        }

        public async Task<List<UsuarioConsulta>> Consulta(EntradaConsultaUsuario entradaConsultaUsuario)
        {
            try
            {
                List<UsuarioConsulta> listUsuario = new List<UsuarioConsulta>();
                var resultado = await _iBddContexto.BcUsuario
                       .Where(o => o.Identificacion == entradaConsultaUsuario.Identificacion).ToListAsync();

                resultado.ForEach(resultado =>
                {
                    var usuarioConsulta = new UsuarioConsulta();
                    usuarioConsulta.Id = resultado.IdUsuario;
                    usuarioConsulta.Identificacion = resultado.Identificacion;
                    usuarioConsulta.Nombre = resultado.Nombre;
                    usuarioConsulta.Genero = resultado.Genero;
                    usuarioConsulta.Direccion = resultado.Direccion;
                    usuarioConsulta.Telefono = resultado.Telefono;
                    usuarioConsulta.Edad = resultado.Edad;
                    listUsuario.Add(usuarioConsulta);
                });
                return listUsuario;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<UsuarioId> CreaAsync(EntradaCreaUsuario entradaUsuarioCrea)
        {
            try
            {
                BCUsuario bcUsuario = new BCUsuario();
                bcUsuario.Identificacion = entradaUsuarioCrea.Usuario.Identificacion;
                bcUsuario.Nombre = entradaUsuarioCrea.Usuario.Nombre;
                bcUsuario.Genero = entradaUsuarioCrea.Usuario.Genero;
                bcUsuario.Edad = entradaUsuarioCrea.Usuario.Edad;
                bcUsuario.Telefono = entradaUsuarioCrea.Usuario.Telefono;
                bcUsuario.Direccion = entradaUsuarioCrea.Usuario.Direccion;

                await _iBddContexto.BcUsuario.AddAsync(bcUsuario);
                await _iBddContexto.SaveChangesAsync();
                return new UsuarioId
                {
                    Id = bcUsuario.IdUsuario
                };

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ActualizaAsync(UsuarioActualiza usuarioActualiza)
        {
            try
            {
                var bcUsuario = await _iBddContexto.BcUsuario.FirstOrDefaultAsync(item => item.IdUsuario == usuarioActualiza.Id);

                bcUsuario.Identificacion = usuarioActualiza.Identificacion;
                bcUsuario.Nombre = usuarioActualiza.Nombre;
                bcUsuario.Genero = usuarioActualiza.Genero;
                bcUsuario.Edad = usuarioActualiza.Edad;
                bcUsuario.Direccion = usuarioActualiza.Direccion;
                bcUsuario.Telefono = usuarioActualiza.Telefono;

                await _iBddContexto.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<bool> EliminaAsync(UsuarioElimina usuarioElimina)
        {
            var bcUsuario = await _iBddContexto.BcUsuario.FirstOrDefaultAsync(item => item.IdUsuario == usuarioElimina.Id && item.Identificacion == usuarioElimina.Identificacion);
            if (bcUsuario == null) return false;

            _iBddContexto.BcUsuario.Remove(bcUsuario);
            await _iBddContexto.SaveChangesAsync();
            return true;
        }


    }
}
