﻿using WSClientes.Dominio.Cliente;
using WSClientes.Entidades.Datos.Entrada;
using WSClientes.Entidades;
using WSClientes.Repositario.Configuraciones.Contexto;
using Microsoft.EntityFrameworkCore;
using WSClientes.Entidades.Datos;
using System.Collections.Generic;


namespace WSClientes.Repositario.Cliente
{
    public class ClienteRepositorio: IClienteRepositorio
    {
        private readonly BddContexto _iBddContexto;

        public ClienteRepositorio( BddContexto iBddContexto)
        {
            _iBddContexto = iBddContexto;
        }

        public async Task<List<ClienteConsulta>> Consulta(EntradaConsultaCliente entradaConsultaCliente)
        {
            try
            {
                var resultado = await _iBddContexto.BcCliente
                    .Include(b => b.IdUsuarioBC)
                    .Where(o => o.IdCliente == (entradaConsultaCliente.IdCliente==null ? o.IdCliente : entradaConsultaCliente.IdCliente))
                    .Where(o => o.IdUsuario == (entradaConsultaCliente.IdUsuario==null ? o.IdUsuario : entradaConsultaCliente.IdUsuario))
                    .ToListAsync();

                List<ClienteConsulta> listCliente = new List<ClienteConsulta>();
                resultado.ForEach(resultado =>
                {
                    var clienteConsulta = new ClienteConsulta();
                    var usuarioConsulta = new UsuarioConsulta();
                    clienteConsulta.Id = resultado.IdCliente;
                    clienteConsulta.Estado = resultado.Estado;
                    clienteConsulta.Contrasenia = resultado.Contrasenia;
                    clienteConsulta.Estado = resultado.Estado;
                    clienteConsulta.IdUsuario = resultado.IdUsuario;
                    listCliente.Add(clienteConsulta);
                });


                return listCliente;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
